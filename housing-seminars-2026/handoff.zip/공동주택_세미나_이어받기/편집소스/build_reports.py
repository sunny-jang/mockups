from pathlib import Path
import re,json,html,subprocess
from urllib.parse import quote
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, Table, TableStyle, Flowable
from reportlab.lib.styles import ParagraphStyle
from pypdf import PdfReader,PdfWriter
from report_extra import R,S

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'outputs'; OUT.mkdir(exist_ok=True)
EXTRA=OUT/'원고_보조자료'; EXTRA.mkdir(exist_ok=True)
WORK=ROOT/'work'; (WORK/'previews').mkdir(exist_ok=True)
FONT='/Users/sunny/Library/Fonts/'
pdfmetrics.registerFont(TTFont('KR',FONT+'NotoSansKR-Regular.ttf'))
pdfmetrics.registerFont(TTFont('KRB',FONT+'NotoSansKR-Black.ttf'))
pdfmetrics.registerFontFamily('KR',normal='KR',bold='KRB',italic='KR',boldItalic='KRB')
NAVY=colors.HexColor('#203A43'); TEAL=colors.HexColor('#397669'); LIGHT=colors.HexColor('#F0F5F2')
INK=colors.HexColor('#26383C'); MUTED=colors.HexColor('#647372'); LINE=colors.HexColor('#D5DEDA')
W,H=A4; M=43; CW=W-2*M
sty={
 'p':ParagraphStyle('p',fontName='KR',fontSize=10.2,leading=17.0,textColor=INK,wordWrap='CJK'),
 'h':ParagraphStyle('h',fontName='KRB',fontSize=11.4,leading=17,textColor=NAVY,wordWrap='CJK'),
 't':ParagraphStyle('t',fontName='KR',fontSize=9.4,leading=14.5,textColor=INK,wordWrap='CJK'),
 'th':ParagraphStyle('th',fontName='KRB',fontSize=9.4,leading=14.5,textColor=colors.white,wordWrap='CJK'),
 'ref':ParagraphStyle('ref',fontName='KR',fontSize=8.3,leading=12.7,textColor=MUTED,wordWrap='CJK'),
 'cap':ParagraphStyle('cap',fontName='KR',fontSize=7.6,leading=11,textColor=MUTED,wordWrap='CJK'),
}

def para(s,k='p'):
    return Paragraph(s.replace('\n','<br/>'),sty[k])

class Diagram(Flowable):
 def __init__(self,kind,w=CW):
    super().__init__();self.kind=kind;self.width=w;self.height=105
 def draw(self):
    c=self.canv; w=self.width
    def rect(x,y,ww,hh,label,fill=LIGHT,fs=9):
        c.setFillColor(fill);c.setStrokeColor(LINE);c.roundRect(x,y,ww,hh,4,fill=1,stroke=1)
        c.setFillColor(NAVY);c.setFont('KR',fs)
        for j,s in enumerate(label.split('\n')):c.drawCentredString(x+ww/2,y+hh/2+(len(label.split('\n'))-1)*6-3-j*12,s)
    def arrow(x1,y1,x2,y2):
        c.setStrokeColor(TEAL);c.setLineWidth(1.2);c.line(x1,y1,x2,y2)
        c.line(x2,y2,x2-4,y2+3);c.line(x2,y2,x2-4,y2-3)
    if self.kind=='flex':
        ww=(w-35)/2
        for x,labs in [(0,['개인실','작업실']),(ww+35,['통합 생활영역'])]:
            c.setStrokeColor(NAVY);c.setLineWidth(1.4);c.rect(x+2,18,ww-4,72)
            rect(x+3,19,55,70,'고정\n영역',colors.HexColor('#DEE8E1'))
            c.setFillColor(NAVY);c.setFont('KR',9)
            if len(labs)==2:
                mid=x+58+(ww-60)/2;c.setDash(4,3);c.line(mid,20,mid,88);c.setDash()
                c.drawCentredString(x+58+(ww-60)/4,53,labs[0]);c.drawCentredString(x+58+(ww-60)*.75,53,labs[1])
            else:c.drawCentredString(x+58+(ww-60)/2,53,labs[0])
        arrow(ww+4,55,ww+29,55)
    elif self.kind=='community':
        ww=105;gap=(w-4*ww)/3
        for i,(a,b) in enumerate([('단위세대','독립·수납'),('주동 출입','인지·접근'),('커뮤니티','교류·활동'),('외부공간','보행·휴식')]):
            x=i*(ww+gap);rect(x,28,ww,54,a+'\n'+b)
            if i<3:arrow(x+ww+3,55,x+ww+gap-3,55)
        c.setFont('KR',8);c.setFillColor(MUTED);c.drawCentredString(w/2,9,'매일 반복되는 이동과 사용 장면을 함께 검토')
    elif self.kind=='layers':
        ww=(w-20)/3
        for i,l in enumerate(['세대 환경\n빛·수납·휴식','단지 생활\n보행·교류·자연','주거 서비스\n안내·조작·관리']):rect(i*(ww+10),25,ww,61,l)
    elif self.kind=='zoning':
        ww=(w-20)/3
        for i,l in enumerate(['조용한 활동\n학습·휴식','전이·지원 영역\n대기·관리·수납','활동적인 공간\n운동·놀이']):rect(i*(ww+10),25,ww,61,l)
    elif self.kind=='support':
        rect(0,52,w,42,'장기간 유지할 요소 | 구조체·공용 기반',colors.HexColor('#DEE8E1'))
        ww=(w-20)/3
        for i,l in enumerate(['벽체·가구','내부 마감','설비·기기']):rect(i*(ww+10),5,ww,34,l)
    elif self.kind=='envelope':
        ww=(w-36)/4
        for i,l in enumerate(['목표 성능','제품 조합','접합 상세','점검·교체']):
            x=i*(ww+12);rect(x,27,ww,56,l)
            if i<3:arrow(x+ww+2,55,x+ww+10,55)

def tableflow(b):
    _,head,rows,widths=b
    widths=widths or [1/len(head)]*len(head)
    data=[[para(x,'th') for x in head]]+[[para(x,'t') for x in row] for row in rows]
    t=Table(data,colWidths=[CW*x for x in widths],hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[LIGHT,colors.white]),
        ('LINEBELOW',(0,1),(-1,-1),.4,LINE)
    ]));return t

def flows(block):
    typ=block[0]
    if typ in ('p','h'):return [(para(block[1],typ),11 if typ=='h' else 0,7)]
    if typ=='table':return [(tableflow(block),2,9)]
    if typ=='diagram':return [(Diagram(block[1]),0,2),(para(block[2],'cap'),0,9)]
    if typ=='box':
        t=Table([[para(block[1],'h')],[para(block[2])]],colWidths=[CW])
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('LINEBEFORE',(0,0),(0,-1),3,TEAL),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,0),10),('BOTTOMPADDING',(0,-1),(-1,-1),10)]))
        return [(t,2,10)]
    if typ=='refs':
        result=[(para('참고자료 | 링크를 누르면 원문으로 이동','h'),10,5)]
        for i,key in enumerate(block[1],1):
            org,title,date,url=S[key];u=quote(url,safe=':/?=&%')
            text=f'[{i}] {html.escape(org)}. <link href="{html.escape(u,quote=True)}" color="#397669">{html.escape(title)}</link>. {html.escape(date)}.'
            result.append((para(text,'ref'),0,4))
        result.append((para('자료 확인 기준: 2026.11.04. 공개 자료와 설계 적용 제안을 구분해 작성.','cap'),3,0))
        return result
    raise ValueError(typ)

def header(c,r,idx,ptitle):
    c.setFillColor(NAVY);c.rect(0,H-10,W,10,fill=1,stroke=0)
    c.setFont('KRB',9);c.drawString(M,H-35,f"RESEARCH {r['id']}  /  {r['kind']}")
    c.drawImage(str(WORK/'aa_logo.png'),W-M-111,H-39,width=111,height=16.8,mask='auto')
    if idx==1:
        c.setFillColor(NAVY);c.setFont('KRB',20)
        for i,l in enumerate(r['title'].split('\n')):c.drawString(M,H-69-i*29,l)
        c.setFillColor(MUTED);c.setFont('KR',9);c.drawString(M,H-118,r['subtitle'])
        return H-136
    else:
        c.setFillColor(NAVY);c.setFont('KRB',19);c.drawString(M,H-73,ptitle)
        c.setFillColor(MUTED);c.setFont('KR',9);c.drawString(M,H-96,r['short']+' | 국내 재개발·재건축 및 공동주택')
        return H-112

def render():
    pdfs=[];layout=[];md=['![AA archigroup](AA_archigroup_logo.png)\n','# 국내 공동주택 설계 연구보고서 6편\n','작성자: 김주성\n','작성일: 2026.11.04\n','트렌드 연구 3편 + 국내 시장조사 3편\n']
    for r in R:
        fname=f"{r['id']}_{r['short'].replace(' ','_')}.pdf";path=OUT/fname
        c=canvas.Canvas(str(path),pagesize=A4);c.setTitle(r['title'].replace('\n',' '));c.setAuthor('김주성')
        md += [f"\n# {r['id']}. {r['title'].replace(chr(10),' ')}\n",r['subtitle']+'\n']
        for idx,(ptitle,blocks) in enumerate(r['pages'],1):
            y=header(c,r,idx,ptitle);md += [f'\n## {idx}쪽. {ptitle}\n']
            for block in blocks:
                for f,before,after in flows(block):
                    y-=before;fw,fh=f.wrap(CW,1000)
                    if y-fh<52:raise RuntimeError(f"OVERFLOW report {r['id']} page {idx} {block[0]} by {52-(y-fh):.1f}pt")
                    f.drawOn(c,M,y-fh);y-=fh+after
                typ=block[0]
                if typ=='p':md.append(re.sub('<[^>]+>','',block[1])+'\n')
                elif typ=='h':md.append('### '+block[1]+'\n')
                elif typ=='box':md+=['**'+block[1]+'**\n',block[2]+'\n']
                elif typ=='table':
                    md.append('| '+' | '.join(block[1])+' |\n'+'|'+' --- |'*len(block[1]))
                    md += ['| '+' | '.join(x.replace('\n',' / ') for x in row)+' |' for row in block[2]];md.append('')
                elif typ=='diagram':md.append(f'![{block[2]}](도식_{block[1]}.png)\n')
                elif typ=='refs':
                    md.append('### 참고자료\n')
                    for i,key in enumerate(block[1],1):
                        org,title,date,url=S[key];md.append(f'{i}. {org}. [{title}]({url}). {date}.')
            c.setStrokeColor(LINE);c.line(M,39,W-M,39);c.setFillColor(MUTED);c.setFont('KR',7.5)
            c.drawString(M,25,'작성자 김주성  |  2026.11.04  |  국내 공동주택 설계 연구')
            c.drawRightString(W-M,25,f"{r['id']}  /  {idx:02d} - 03")
            layout.append({'report':r['id'],'page':idx,'bottom':round(y,1)});c.showPage()
        c.save();pdfs.append(path)
    merged=PdfWriter()
    for r,path in zip(R,pdfs):merged.append(str(path),outline_item=r['id']+' '+r['short'])
    merged.add_metadata({'/Author':'김주성','/Title':'국내 공동주택 설계 연구보고서 6편'})
    with open(OUT/'00_공동주택_연구보고서_6편_통합.pdf','wb') as f:merged.write(f)
    (EXTRA/'수정용_통합원고.md').write_text('\n'.join(md),encoding='utf-8')
    (WORK/'content.json').write_text(json.dumps({'reports':R,'sources':S},ensure_ascii=False),encoding='utf-8')
    (WORK/'layout.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2))
    print(json.dumps(layout,ensure_ascii=False))
    print('PDF pages:',[(x.name,len(PdfReader(x).pages)) for x in pdfs])
    kinds=sorted({b[1] for r in R for _,blocks in r['pages'] for b in blocks if b[0]=='diagram'})
    pop='/Users/sunny/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/bin/pdftoppm'
    for k in kinds:
        f=WORK/f'diagram_{k}.pdf';c=canvas.Canvas(str(f),pagesize=(CW,108));Diagram(k).drawOn(c,0,0);c.save()
        subprocess.run([pop,'-png','-r','170','-singlefile',str(f),str(EXTRA/f'도식_{k}')],check=True,capture_output=True)

if __name__=='__main__':render()
