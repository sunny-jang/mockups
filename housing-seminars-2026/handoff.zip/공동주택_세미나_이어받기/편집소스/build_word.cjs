const fs=require('fs');
const path=require('path');
const {Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,WidthType,ShadingType,HeadingLevel,PageBreak,Header,Footer,AlignmentType,ExternalHyperlink,ImageRun,PageNumber}=require('/Users/sunny/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/docx');
const root=path.dirname(__dirname),out=path.join(root,'outputs');
const data=JSON.parse(fs.readFileSync(path.join(__dirname,'content.json'),'utf8'));
const WIDTH=10180,FONT='Noto Sans KR';
function runs(s,size=20,color='26383C',bold=false){
  let b=bold;let result=[];
  for(const x of s.split(/(<b>|<\/b>|\n)/)){
    if(x==='<b>')b=true;else if(x==='</b>')b=bold;else if(x==='\n')result.push(new TextRun({break:1}));
    else if(x)result.push(new TextRun({text:x,font:FONT,size,color,bold:b}));
  }return result;
}
const p=(s,opt={})=>new Paragraph({...opt,children:runs(s,opt.size||20,opt.color||'26383C',!!opt.bold),snapToGrid:false,spacing:{before:0,after:110,line:320,lineRule:'exact',...opt.spacing}});
const heading=s=>p(s,{heading:HeadingLevel.HEADING_2,size:23,bold:true,color:'203A43',spacing:{before:170,after:90,line:320},keepNext:true});
function table(b){
 const [,head,rows,ws]=b;const weights=ws||head.map(()=>1/head.length);let widths=weights.map(x=>Math.round(x*WIDTH));widths[widths.length-1]+=WIDTH-widths.reduce((a,b)=>a+b,0);
 return new Table({width:{size:WIDTH,type:WidthType.DXA},columnWidths:widths,rows:[head,...rows].map((row,i)=>new TableRow({cantSplit:true,tableHeader:i===0,children:row.map((s,j)=>new TableCell({width:{size:widths[j],type:WidthType.DXA},shading:{type:ShadingType.CLEAR,fill:i===0?'203A43':i%2?'F0F5F2':'FFFFFF'},margins:{top:110,bottom:110,left:140,right:140},children:[p(s,{size:18,color:i===0?'FFFFFF':'26383C',bold:i===0,spacing:{after:0,line:270}})]}))}))});
}
let children=[];
for(const r of data.reports){
 for(let pi=0;pi<r.pages.length;pi++){
  const [title,blocks]=r.pages[pi];
  children.push(p(`RESEARCH ${r.id} / ${r.kind} / 작성자 김주성 / 2026.11.04`,{size:17,bold:true,color:'397669',spacing:{after:160}}));
  for(const line of (pi===0?r.title:title).split('\n'))children.push(p(line,{heading:HeadingLevel.HEADING_1,size:36,bold:true,color:'203A43',spacing:{after:60,line:460},keepNext:true}));
  children.push(p(pi===0?r.subtitle:r.short+' | 국내 재개발·재건축 및 공동주택',{size:17,color:'647372',spacing:{after:180}}));
  for(const b of blocks){
   if(b[0]==='p')children.push(p(b[1]));
   else if(b[0]==='h')children.push(heading(b[1]));
   else if(b[0]==='box'){
    children.push(p(b[1],{size:22,bold:true,color:'397669',spacing:{before:100,after:80},keepNext:true}));
    children.push(p(b[2],{shading:{type:ShadingType.CLEAR,fill:'F0F5F2'}}));
   }
   else if(b[0]==='table'){children.push(table(b));children.push(p('',{size:3,spacing:{after:0,line:60}}));}
   else if(b[0]==='diagram'){
    children.push(new Paragraph({children:[new ImageRun({type:'png',data:fs.readFileSync(path.join(out,'원고_보조자료',`도식_${b[1]}.png`)),transformation:{width:670,height:142}})],spacing:{after:40}}));
    children.push(p(b[2],{size:15,color:'647372',spacing:{after:110,line:220}}));
   }
   else if(b[0]==='refs'){
    children.push(heading('참고자료 | 원문 링크'));
    b[1].forEach((key,i)=>{const [org,t,date,url]=data.sources[key];children.push(new Paragraph({snapToGrid:false,children:[...runs(`[${i+1}] ${org}. `,16,'647372'),new ExternalHyperlink({link:encodeURI(url),children:[new TextRun({text:t,font:FONT,size:16,color:'397669',underline:{}})]}),...runs(`. ${date}.`,16,'647372')],spacing:{after:65,line:240,lineRule:'exact'}}));});
    children.push(p('자료 확인 기준: 2026.11.04. 공개 자료와 설계 적용 제안을 구분해 작성.',{size:15,color:'647372'}));
   }
  }
  if(!(r.id==='06'&&pi===2))children.push(new Paragraph({children:[new PageBreak()]}));
 }
}
const doc=new Document({creator:'김주성',title:'국내 공동주택 설계 연구보고서 6편 - 수정용 원고',description:'트렌드 연구 3편 및 국내 시장조사 3편',styles:{default:{document:{run:{font:FONT,size:20},paragraph:{spacing:{line:320}}}}},sections:[{properties:{page:{size:{width:11906,height:16838},margin:{top:900,bottom:800,left:863,right:863,header:260}}},headers:{default:new Header({children:[new Paragraph({alignment:AlignmentType.RIGHT,children:[new ImageRun({type:'png',data:fs.readFileSync(path.join(__dirname,'aa_logo.png')),transformation:{width:148,height:22.4}})],spacing:{after:0,line:400,lineRule:'exact'}})]})},footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.RIGHT,children:[new TextRun({text:'작성자 김주성  |  주거설계 연구자료  |  ',font:FONT,size:14,color:'647372'}),new TextRun({children:[PageNumber.CURRENT],size:14})]})]})},children}]});
Packer.toBuffer(doc).then(b=>{fs.writeFileSync(path.join(out,'수정용_공동주택_연구보고서_6편.docx'),b);console.log('Editable Word manuscript created');});
